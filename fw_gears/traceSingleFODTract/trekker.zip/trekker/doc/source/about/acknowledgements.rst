Acknowledgements
================

.. figure:: acknowledgements_NICR.png
	:scale: 40 %
	:target: https://nicr.ini.usc.edu/

.. figure:: acknowledgements_NBE.png
	:scale: 40 %
	:target: https://www.aalto.fi/en/department-of-neuroscience-and-biomedical-engineering

.. figure:: acknowledgements_C2B.png
	:scale: 40 %
