How to cite?
============

A journal publication which provides detailed explanation of the algorithm and extensive experiments is currently under review [Aydogan2019a]_. For now please cite our ISMRM 2019, Montreal abstract [Aydogan2019b]_.


.. [Aydogan2019a] Aydogan D.B., Shi Y., "Parallel transport tractography", under review

.. [Aydogan2019b] Aydogan D.B., Shi Y., "A novel fiber tracking algorithm using parallel transport frames", Proceedings of the 27th Annual Meeting of the International Society of Magnetic Resonance in Medicine (ISMRM) 2019
