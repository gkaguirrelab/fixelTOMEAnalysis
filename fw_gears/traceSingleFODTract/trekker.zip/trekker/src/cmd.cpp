#include "trekker.h"
#include <cstdlib>

int main (int argc, char **argv) {

	Trekker trekker(argc, argv);
	return EXIT_SUCCESS;

}
