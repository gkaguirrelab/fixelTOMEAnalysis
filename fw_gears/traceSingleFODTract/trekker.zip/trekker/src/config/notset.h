#ifndef SRC_CONFIG_NOTSET_H_
#define SRC_CONFIG_NOTSET_H_

enum {
	NOTSET = -1
};

#endif
