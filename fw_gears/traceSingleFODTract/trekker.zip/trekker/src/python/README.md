Trekker
=======

Python package for parallel transport tractography (PTT). PTT is capable of reconstructing geometrically smooth and topographically organized fiber bundles.

For complete documentation with tutorials and examples, visit [https://dmritrekker.github.io/](https://dmritrekker.github.io/).
